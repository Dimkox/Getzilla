---
description: Senior software engineer who implements stories and code changes. Use when the user asks to talk to Amelia or requests the developer agent
---

LOAD the FULL {project-root}/.agents/skills/bmad-agent-dev/SKILL.md, READ its entire contents and follow its directions exactly!
